# Banner designer

The banner designer helps create simple banners without needing extra software. Upload your own images, reposition them in the template and resize them by selecting the corners of the image in the design. Fill in the details and save the entire design or just the background image.
